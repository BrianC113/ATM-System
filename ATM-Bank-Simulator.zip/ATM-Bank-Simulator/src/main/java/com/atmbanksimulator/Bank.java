package com.atmbanksimulator;

// ===== 📚🌐Bank (Domain / Service / Business Logic) =====

// Bank class: a simple implementation of a bank, containing a list of bank accounts
// and has a currently logged-in account (loggedInAccount).
public class Bank {

    // Maximum number of accounts the bank can hold
    private int maxAccounts = 10;

    // Current number of accounts in the bank
    private int numAccounts = 0;

    // Array to hold BankAccount objects
    private BankAccount[] accounts = new BankAccount[maxAccounts];

    // Currently logged-in account
    private BankAccount loggedInAccount = null;

    // Factory method to create BankAccount objects
    public BankAccount makeBankAccount(String accNumber,
                                       String accPasswd,
                                       double balance) {

        return new BankAccount(accNumber, accPasswd, balance);
    }

    // Add a BankAccount object to the bank
    public boolean addBankAccount(BankAccount a) {

        if (numAccounts < maxAccounts) {

            accounts[(int) numAccounts] = a;
            numAccounts++;
            return true;

        } else {
            return false;
        }
    }

    // Overloaded version of addBankAccount
    public boolean addBankAccount(String accNumber,
                                  String accPasswd,
                                  double balance) {

        return addBankAccount(
                makeBankAccount(accNumber, accPasswd, balance)
        );
    }
    //check if an account number already exists
    public boolean accountExists(String accNumber) {
        for (BankAccount b : accounts) {

            //skip empty array spaces
            //loops through all accounts, checks existing account numbers
            // then returns true if found or false if otherwise
            if (b != null) { //https://www.geeksforgeeks.org/java/null-pointer-exception-in-java/
                if (b.getAccNumber().equals(accNumber)) {
                    return true;
                }
                //https://www.w3schools.com/java/java_arrays_loop.asp
                //https://www.w3schools.com/java/java_arrays_reallife.asp
            }
        }
        return false;
    }

    public boolean createAccount(String accNumber, String accPasswd, double balance) {

        //check if account already exists
        if (accountExists(accNumber)) {
            return false;
        }

        //create and add account
        return addBankAccount(accNumber, accPasswd, balance);
    }

    //Account transfer
    public boolean transfer(String fromAccount, String toAccount, double amount) {
        BankAccount sender = null;
        BankAccount receiver = null;

        //Find both accounts
        for (int i = 0; i < numAccounts; i++) {
            BankAccount b = accounts[i];

            if (b != null && b.getAccNumber().equals(fromAccount)) {
                sender = b;
            }
            if (b != null && b.getAccNumber().equals(toAccount)) {
                receiver = b;
            }
        }
        //Validation
        //https://www.w3schools.com/java/java_arrays_reallife.asp
        if (sender == null || receiver == null) {
            return false;
        }
        if (amount <= 0) {
            return false;
        }
        //Withdraw from sender
        if (!sender.withdraw(amount)) {
            return false;
        }
        //Deposit into receiver
        receiver.deposit(amount);
        return true;
    }

    // Login method
    public boolean login(String accountNumber, String password) {

        logout();

        // Search only existing accounts
        for (int i = 0; i < numAccounts; i++) {

            BankAccount b = accounts[(int) i];

            if (b.getAccNumber().equals(accountNumber)
                    && b.getaccPasswd().equals(password)) {

                loggedInAccount = b;
                return true;
            }
        }

        loggedInAccount = null;
        return false;
    }

    // Logout
    public void logout() {
        loggedInAccount = null;
    }

    // Check whether an account is logged in
    public boolean loggedIn() {

        if (loggedInAccount == null) {
            return false;
        } else {
            return true;
        }
    }

    // Deposit money
    public boolean deposit(double amount) {

        if (loggedIn()) {
            return loggedInAccount.deposit(amount);
        } else {
            return false;
        }
    }

    // Withdraw money
    public boolean withdraw(double amount) {

        if (loggedIn()) {
            return loggedInAccount.withdraw(amount);
        } else {
            return false;
        }
    }

    //change password
    public boolean changePasswd(String oldPasswd, String newPasswd) {
        //https://www.geeksforgeeks.org/java/encapsulation-in-java/
        //check if user is logged in
        if (loggedIn()) {
            return loggedInAccount.changePasswd(oldPasswd, newPasswd);
        } else {
            return false;
        }
    }

    // Get account balance
    public double getBalance() {

        if (loggedIn()) {
            return loggedInAccount.getBalance();
        } else {
            return 0;
        }
    }
}