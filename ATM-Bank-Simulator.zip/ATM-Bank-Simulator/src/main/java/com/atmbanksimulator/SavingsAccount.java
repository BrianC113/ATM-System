package com.atmbanksimulator;

public class SavingsAccount extends BankAccount {
    //https://www.w3schools.com/java/java_inheritance.asp - To inherit from a class, use the extends keyword
    //fixed interest rate
    private double interestRate = 0.05;
    //constructor
    protected SavingsAccount(String a, String p, double b) {
        super(a, p, b);
    }

    //add interest to balance
    public void addInterest() {

        double interest = (balance * interestRate);
        //https://www.geeksforgeeks.org/java/typecasting-in-java/
        balance = balance + interest;
    }
}
