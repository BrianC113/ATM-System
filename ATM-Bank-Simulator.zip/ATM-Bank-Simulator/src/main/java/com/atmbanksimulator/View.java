package com.atmbanksimulator;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;

// ===== 🙂 View (Eyes / Ears / Nose / Mouth / Face) =====

// The View class creates the GUI for the application.
// It does not know anything about business logic;
// it only updates the display when notified by the UIModel.
class View {
    int H = 500;
    int W = 400;

    Controller controller;

    private Label laMsg;
    private TextField tfInput;
    private TextArea taResult;
    private ScrollPane scrollPane;
    private GridPane grid;
    private GridPane buttonPane;

    public void start(Stage window) {

        grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        grid.setId("Layout");

        laMsg = new Label("Welcome to the ATM");
        grid.add(laMsg, 0, 0);

        tfInput = new TextField();
        tfInput.setEditable(false);
        tfInput.setPrefHeight(40);
        grid.add(tfInput, 0, 1);

        taResult = new TextArea();
        taResult.setEditable(false);
        taResult.setWrapText(true);

        scrollPane = new ScrollPane();
        scrollPane.setContent(taResult);
        scrollPane.setPrefHeight(150);
        grid.add(scrollPane, 0, 2);

        buttonPane = new GridPane(); //https://www.geeksforgeeks.org/java/javafx-how-to-set-padding-between-nodes-of-a-gridpane/
        buttonPane.setHgap(5);
        buttonPane.setVgap(5);
        buttonPane.setId("Buttons");
        buttonPane.setPrefSize(W, 200);
        buttonPane.setAlignment(javafx.geometry.Pos.CENTER);

        String[][] buttonTexts = {
                {"7", "8", "9", "", "Dep", "Pwd"},
                {"4", "5", "6", "", "W/D", "New"},
                {"1", "2", "3", "", "Bal", "Fin"},
                {"CLR", "0", "Rpt", "", "Trf", "Ent"}
        };

        for (int row = 0; row < buttonTexts.length; row++) {
            for (int col = 0; col < buttonTexts[row].length; col++) {

                String text = buttonTexts[row][col];

                if (text.isEmpty()) {
                    continue; // skips blank slots cleanly
                }

                Button btn = new Button(text);
                btn.setPrefSize(60, 50);
                btn.setOnAction(this::buttonClicked);

                buttonPane.add(btn, col, row);
            }
        }

        grid.add(buttonPane, 0, 3);

        Scene scene = new Scene(grid, W, H);
        scene.getStylesheets().add("atm.css");

        window.setScene(scene);
        window.setTitle("ATM Simulator");
        window.show();
    }

    private void buttonClicked(ActionEvent event) {
        Button b = (Button) event.getSource();
        String text = b.getText();
        System.out.println("View::buttonClicked: " + text);
        controller.process(text);
    }

    public void update(String msg, String tfInputMsg, String taResultMsg) {
        laMsg.setText(msg);
        tfInput.setText(tfInputMsg);
        taResult.setText(taResultMsg);
    }
}