package com.atmbanksimulator;

// ===== 📚🌐BankAccount (Domain / Service / Business Logic) =====

// BankAccount class:
// - Stores instance variables for account number, password, and balance
// - Provides methods to withdraw, deposit, check balance, etc.
public class BankAccount {
    protected String accNumber = "";
    protected String accPasswd ="";
    protected double balance = 0; //to allow for decimal(cents) transactions
// https://www.w3schools.com/java/java_inheritance.asp - it was set to private, the class would not be able to access it.

    public BankAccount() {}
    public BankAccount(String a, String p, double b) {
        accNumber = a;
        accPasswd = p;
        balance = b;
    }

    // Withdraw money from this account.
    // Returns true if successful, or false if the amount is negative or exceeds the current balance.
    public boolean withdraw( double amount ) {
        if (amount < 0 || balance < amount) {
            return false;
        } else {
            balance = balance - amount;  // subtract amount from balance
            return true;
        }
    }

    // deposit the amount of money into this account.
    // Return true if successful,or false if the amount is negative
    public boolean deposit( double amount ) {
        if (amount < 0) {
            return false;
        } else {
            balance = balance + amount;  // add amount to balance
            return true;
        }
    }

    // Getter for the account balance
    // Returns the current balance of this account
    public double getBalance() {
        return balance;
    }

    // Getter for the account number
    public String getAccNumber() {
        return accNumber;
    }
    // Getter for the account password
    public String getaccPasswd() {
        return accPasswd;
    }
    //change account password
    public boolean changePasswd(String oldPasswd, String newPasswd) {
        //check old password
        //https://www.geeksforgeeks.org/java/string-equals-method-in-java/ - It compares the value's character by character, irrespective of whether two strings are stored in the same memory location.
        if (!accPasswd.equals(oldPasswd)) {
            return false;
        }
        //validate new password length
        if (newPasswd.length() < 4) {
            return false;
        }
        //change password
        accPasswd = newPasswd;
        return true;
    }
}
