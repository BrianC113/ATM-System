package com.atmbanksimulator;
//inherits from BankAccount
//https://www.w3schools.com/java/java_inheritance.asp - To inherit from a class, use the extends keyword
public class StudentAccount extends BankAccount {
    //max amount allowed per withdrawal
    private double withdrawLimit = 100;
    //constructor
    //https://www.geeksforgeeks.org/java/super-keyword/ - The super keyword can also be used to access the parent class constructor
    public StudentAccount(String a, String p, double b) {
        super(a, p, b);
    }

    //override withdraw method
    @Override
    //https://www.geeksforgeeks.org/java/overriding-in-java/ - catches mistakes like typos in method names
    public boolean withdraw(double amt) {

        //reject amount above limit
        if (amt > withdrawLimit) {
            return false;
        }

        //else use normal logic
        return super.withdraw(amt);
    }
}
