package com.atmbanksimulator;

// ===== 🧠 UIModel (Brain) =====

// The UIModel represents all the actual content and functionality of the app
// For the ATM, it keeps track of the information shown in the display
// (the laMsg and two tfInput boxes), and the interaction with the bank, executes
// commands provided by the controller and tells the view to update when
// something changes
public class UIModel {
    View view; // Reference to the View (part of the MVC setup)
    private Bank bank; // The ATM communicates with this Bank

    // The ATM UIModel can be in one of three states:
    // 1. Waiting for an account number
    // 2. Waiting for a password
    // 3. Logged in (ready to process requests for the logged-in account)
    // We represent each state with a String constant.
    // The 'final' keyword ensures these values cannot be changed.
    private final String STATE_ACCOUNT_NO = "account_no";
    private final String STATE_PASSWORD = "password";
    //private final String STATE_TRANSFER_ACCOUNT = "transfer_account";
    //private final String STATE_TRANSFER_AMOUNT = "transfer_amount";
    private final String STATE_LOGGED_IN = "logged_in";
    private final String STATE_CHANGE_PASSWORD = "change_password";
    private final String STATE_CREATE_ACCOUNT_NUMBER = "create_account_number";
    private final String STATE_CREATE_ACCOUNT_PASSWORD = "create_account_password";
    private final String STATE_CREATE_ACCOUNT_BALANCE = "create_account_balance";
    private final String STATE_TRANSFER_TARGET = "transfer_target";

    // Variables representing the state and data of the ATM UIModel
    private String state = STATE_ACCOUNT_NO;    // Current state of the ATM
    private String accNumber = "";         // Account number being typed
    private String accPasswd = "";         // Password being typed
    private String oldPasswd = "";          //old password being typed
    private String newPasswd = "";          //new password being typed
    private String newAccountNumber = "";
    private int loginAttempts = 0;
    private String newAccountPassword = "";
    private String transferTargetAccount = "";
    private double transferAmount = 0;


    // Variables shown on the View display
    private String message;                // Message label text
    private String numberPadInput;         // Current number displayed in the TextField (as a string)
    private String result;                 // Contents of the TextArea (may be multiple lines)

    // UIModel constructor: pass a Bank object that the ATM interacts with
    public UIModel(Bank bank) {
        this.bank = bank;
    }

    // Initialize the ATM UIModel: this method is called by Main when starting the app
    // - Set state to STATE_ACCOUNT_NO
    // - Clear the numberPadInput - numbers displayed in the TextField
    // - Display the welcome message and user instructions
    public void initialise() {
        setState(STATE_ACCOUNT_NO);
        numberPadInput = "";
        message = "Welcome to ATM Banking";
        result = "Choose an option: \n\n" +
                 "- Enter Account Number to Login\n" +
                 "- Press New to Create Account";
        update();
    }

    // Reset the ATM UIModel after an invalid action or logout:
    // - Set state to STATE_ACCOUNT_NO
    // - Clear the numberPadInput
    // - Display the provided message and user instructions
    private void reset(String msg) {
        setState(STATE_ACCOUNT_NO);
        numberPadInput = "";
        message = msg;
        result = "Enter your account number\nFollowed by \"Ent\"";
    }

    // Change the ATM state and print a debug message whenever the state changes
    private void setState(String newState)
    {
        if ( !state.equals(newState) )
        {
            String oldState = state;
            state = newState;
            System.out.println("UIModel::setState: changed state from "+ oldState + " to " + newState);
        }
    }

    // These process**** methods are called by the Controller
    // in response to specific button presses on the GUI.

    // Handle a number button press: append the digit to numberPadInput
    public void processNumber(String numberOnButton) {


        boolean isDecimal = numberOnButton.equals(".");

        boolean moneyState =
                state.equals(STATE_LOGGED_IN)
                || state.equals(STATE_CREATE_ACCOUNT_BALANCE);
        //allow decimal points only for money
        if (isDecimal && !moneyState) {
            return;
        }

        //prevent multiple decimal points
        if (numberOnButton.equals(".") && numberPadInput.contains(".")) {
            return;
        }
        //add pressed button text
        numberPadInput += numberOnButton;

        // Optional extension:
        // Improve feedback by showing what the number is being entered for based on the current state.
        // e.g.  if state is STATE_ACCOUNT_NO, display "Receiving Account Number, Beep 5 received"
        if (state.equals(STATE_ACCOUNT_NO)) {
            message = "Enter Account Number";
        }
        else if (state.equals(STATE_PASSWORD)) {
            message = "Enter Password";
        }
        else if (state.equals(STATE_LOGGED_IN)) {
            message = "Entering Amount";
        }
        else {
            message = "Input Received";
        }
        update();
    }

    // Handle the Clear button: reset the current number stored in numberPadInput
    public void processClear() {
        // Optional extension:
        // Improve feedback by showing what was cleared depending on the current state.
        // e.g. if state is STATE_ACCOUNT_NO, display "Account Number cleared: 123"
        if (!numberPadInput.isEmpty()) {
            numberPadInput = "";
            message = "Input Cleared";
            update();
        }
    }

    // Handle the Enter button.
    // This is a more complex method: pressing Enter causes the ATM to change state,
    // progressing from STATE_ACCOUNT_NO → STATE_PASSWORD → STATE_LOGGED_IN,
    // and back to STATE_ACCOUNT_NO when logging out.
    public void processEnter()
    {
        // The action depends on the current ATM state
        switch ( state )
        {
            case STATE_ACCOUNT_NO:
                // Waiting for a complete account number
                // If nothing was entered, reset with "Invalid Account Number"
                if (numberPadInput.equals("")) {
                    message = "Invalid Account Number";
                    reset(message);
                }
                else{
                    // Save the entered number as accNumber, clear numberPadInput,
                    // update the state to expect password, and provide instructions
                    accNumber = numberPadInput;
                    numberPadInput = "";
                    setState(STATE_PASSWORD);
                    message = "Account Number Accepted";
                    result = "Now enter your password\nFollowed by \"Ent\"";
                }
                break;

            case STATE_PASSWORD:
                // Waiting for a password
                // Save the typed number as accPasswd, clear numberPadInput,
                // then contact the bank to attempt login
                accPasswd = numberPadInput;
                numberPadInput = "";
                if ( bank.login(accNumber, accPasswd) )
                {
                    // Successful login: change state to STATE_LOGGED_IN and provide instructions
                    setState(STATE_LOGGED_IN);
                    loginAttempts = 0;
                    message = "Logged In";
                    result = "Choose a transaction: \n\n\" " +
                            " Dep = Deposit\n" +
                            " W/D = Cash Withdraw\n" +
                            " Bal = Balance\n" +
                            " Pwd = Change Password\n" +
                            " New = New Account\n" +
                            " Trf = Transfer\n" +
                            " Fin = Logout";
                } else {
                    // Login failed: reset ATM and display error
                    loginAttempts++;

                    if (loginAttempts >= 3) {
                        loginAttempts = 0;
                        accNumber = "";
                        accPasswd = "";
                        reset("Too many failed attempts");
                    }
                    else {
                        message = "Login failed (" + loginAttempts + "/3 attempts)";
                        result = "Re-enter password\n" + "Then press Ent";
                    }
                }
                break;

            case STATE_CHANGE_PASSWORD:
                //save old password first
                if (oldPasswd.equals("")) {

                    oldPasswd = numberPadInput;
                    numberPadInput = "";
                    message = "Enter NEW password \nThen press \"Ent\"";
                }
                else {
                    newPasswd = numberPadInput;
                    if (bank.changePasswd(oldPasswd, newPasswd)) {
                        message = "Password Changed Successfully";
                        result = "Your password has been updated";
                    } else {
                        message = "Password Change Failed";
                        result = "Wrong or Invalid Password";
                    }

                    //clear stored passwords
                    oldPasswd = "";
                    newPasswd = "";
                    numberPadInput = "";
                    setState(STATE_LOGGED_IN);
                }
                break;

            case STATE_CREATE_ACCOUNT_NUMBER:
                newAccountNumber = numberPadInput;
                if (bank.accountExists(newAccountNumber)) {

                    message = "Account already exists";
                    reset(message);
                } else {

                    numberPadInput = "";
                    setState(STATE_CREATE_ACCOUNT_PASSWORD);
                    message = "Enter New Account Password";
                    result = "Press Ent when done";
                }
                break;

            case STATE_CREATE_ACCOUNT_PASSWORD:
                if (numberPadInput.length() < 4) {

                    message = "Password must be at least 4 digits";
                    result = "Enter New Account Password";
                    numberPadInput = "";
                } else {
                    newAccountPassword = numberPadInput;
                    numberPadInput = "";

                    setState(STATE_CREATE_ACCOUNT_BALANCE);

                    message = "Enter Starting Balance";
                    result = "Press Ent when done";
                }

                break;

            case STATE_CREATE_ACCOUNT_BALANCE:
                double balance = parseValidAmount(numberPadInput);

                if( balance <= 0){
                    message = "Invalid Balance";
                    result = "Enter Starting Balance";
                    numberPadInput = "";

                } else {

                    bank.addBankAccount(
                            newAccountNumber, newAccountPassword, balance
                    );

                    message = "Account Created Successfully";
                    result = "New Account Number: " + newAccountNumber;

                    numberPadInput = "";
                    newAccountNumber = "";
                    newAccountPassword = "";

                    setState(STATE_ACCOUNT_NO);
                }
                break;
            case STATE_TRANSFER_TARGET:
                transferTargetAccount = numberPadInput;

                if (transferTargetAccount.equals(accNumber)) {
                    message = "Cannot Transfer To Same Account";
                    result = "Enter different account number";
                }
                else if (!bank.accountExists(transferTargetAccount)) {
                    message = "Target Account Not Found";
                    result = "Enter valid account number";
                }
                else {
                    if (bank.transfer(accNumber, transferTargetAccount, transferAmount)) {
                        message = "Transfer Successful";
                        result = "Transferred: " +
                        transferAmount +
                        "\nTo Account: " +
                        transferTargetAccount +
                        "\nRemaining Balance: " + bank.getBalance();
                    }
                    else {
                        message = "Transfer Failed";
                        result = "Insufficient Funds";
                    }
                    setState(STATE_LOGGED_IN);
                }
                numberPadInput = "";
                break;

            case  STATE_LOGGED_IN:
            default:
                // Do nothing for other states (user is already logged in)
        }

        update(); // Refresh the GUI to show messages and input
    }

    /**
     * Parses a string into a valid transaction amount.
     * - If the string is empty, invalid, or consists only of zeros, returns 0.
     * - Otherwise, returns the integer value.
     *
     * Purpose:
     * Helper method for validating user-entered amounts in transactions (Deposit, Withdraw, etc.).
     *
     * Note: If you later add features like Transfer, this method can be reused.
     */
    private double parseValidAmount(String number) {
        if (number.isEmpty()) {
            return 0;
        }
        try {
            return Double.parseDouble(number);
        } catch (NumberFormatException e) {
            return 0; // Invalid input -> treated as 0
        }
    }

    // Handle the Balance button:
    // - If the user is logged in, retrieve the current balance and update messages/results accordingly
    // - Otherwise, reset the ATM and display an error message
    // https://www.geeksforgeeks.org/system-design/state-design-pattern-in-java/
    public void processBalance() {
        if (state.equals(STATE_LOGGED_IN) ) {
            numberPadInput = "";
            message = "Balance Available";
            result = "Your Balance is: " + bank.getBalance();
        } else {
            reset("You are not logged in");
        }
        update();
    }

    // Handle the Withdraw button:
    // If the user is logged in, attempt to withdraw the amount entered;
    // otherwise, reset the ATM and display an error message.
    // Reads the amount from numberPadInput, validates it, and updates messages/results accordingly.
    public void processWithdraw() {
        if (state.equals(STATE_LOGGED_IN)) {
            double amount = parseValidAmount(numberPadInput);
            if (amount > 0) {
                if(bank.withdraw( amount )){
                    message = "Withdraw Successful";
                    result = "Withdrawn: " + numberPadInput;
                }
                else{
                    message = "Withdraw Failed: Insufficient Funds";
                    result = "Now enter the amount\nThen press transaction\n(Dep = Deposit, W/D = Withdraw)";
                }
            }
            else{
                message = "Invalid Amount";
                result = "Now enter the amount\nThen press transaction\n(Dep = Deposit, W/D = Withdraw)";
            }
            numberPadInput = "";
        }
        else {
            reset("You are not logged in");
        }
        update();
    }

    // Handle the Deposit button:
    // - If the user is logged in, deposit the amount entered into the bank
    // - Reads the amount from numberPadInput, validates it, and updates messages/results accordingly
    // - Otherwise, reset the ATM and display an error message
    public void processDeposit() {
        if (state.equals(STATE_LOGGED_IN)) {
            double amount = parseValidAmount(numberPadInput);
            if (amount > 0) {
                bank.deposit( amount );
                message = "Deposit Successful";
                result = "Deposited: " + numberPadInput;
            }
            else {
                message = "Invalid Amount";
                result = "Now enter the amount\nThen press transaction\n(Dep = Deposit, W/D = Withdraw)";
            }
            numberPadInput = "";
        }
        else {
            reset("You are not logged in");
        }
        update();
    }

    public void processChangePassword() {

        if (!state.equals(STATE_LOGGED_IN)) {
            reset("You are not logged in");
            update();
            return;
        }

        setState(STATE_CHANGE_PASSWORD);
        numberPadInput = "";
        message = "Enter OLD password then press Ent";
        result = "";
        update();
    }
    // Handle the Finish button:
    // - If the user is logged in, log out
    // - Otherwise, reset the ATM and display an error message
    public void processFinish() {
        if (state.equals(STATE_LOGGED_IN) ) {
            bank.logout();
            setState(STATE_ACCOUNT_NO);
            numberPadInput = "";
            message = "Session Ended";
            result = "Thank you for using the ATM\n" +
                    "Have a nice day!";
        } else {
            reset("You are not logged in");
        }
        update();
    }

    // Handle unknown or invalid buttons for the current state:
    // - Reset the ATM and display an "Invalid Command" message
    public void processUnknownKey(String action) {
        reset("Invalid Command");
        result = "Please try again";
        update();
    }

    // Notify the View of changes by calling its update method
    private void update() {
        view.update(message,numberPadInput, result);
    }


    public void processCreateAccount() {
        setState(STATE_CREATE_ACCOUNT_NUMBER);

        numberPadInput = "";
        newAccountNumber = "";
        newAccountPassword = "";

        message = "Enter Account Number";
        result = "Press Ent when done";
        update();
    }

    public void processTransfer() {
        if (!state.equals(STATE_LOGGED_IN)) {
            reset("You are not logged in");
            update();
            return;
        }
        //read amount
        transferAmount = parseValidAmount(numberPadInput);

        if (transferAmount <= 0) {
            message = "Invalid Transfer Amount";
            result = "Enter amount first\n" +
                    "Then press Trf";
            numberPadInput = "";
            update();
            return;
        }
        numberPadInput = "";
        //move to target account
        setState(STATE_TRANSFER_TARGET);
        message = "Enter Target Account";
        result = "Enter account number\nThen press Ent";
        update();

    }
}

