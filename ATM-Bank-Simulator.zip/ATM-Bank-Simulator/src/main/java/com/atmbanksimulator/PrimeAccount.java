package com.atmbanksimulator;

public class PrimeAccount extends BankAccount{
    //https://www.w3schools.com/java/java_inheritance.asp - To inherit from a class, use the extends keyword
    //overdraft limit
    private double overdraftLimit = 200;
    //constructor
    public PrimeAccount(String a, String p, double b) {
        super(a,p,b);
    }

    //override withdraw method
    @Override
    //https://www.geeksforgeeks.org/java/overriding-in-java/ - catches mistakes like typos in method names
    public boolean withdraw(double amt) {

        //reject negative numbers
        if (amt < 0) {
            return false;
        }
        //allow overdraft withdrawals
        if (balance + overdraftLimit >= amt) {
            balance =  balance - amt;
            return true;
        }
        return false;
    }
}
